const Telegraf = require('telegraf').Telegraf

const bot = new Telegraf('5217044113:AAHxmkSxpFcCRxrm1DvFj8eGuRxVf---jt0')

const axios = require('axios')
const { Context } = require('telegraf')
const { callback } = require('telegraf/typings/button')

bot.start(ctx => {
    bot.telegram.sendMessage(-1001629127444, 'New User\nUsername @' + ctx.from.username + '\nName: ' + ctx.from.first_name + '\nUserid: ' + ctx.from.id)
    ctx.reply('<i>Hello ' + ctx.from.first_name + ' 🎉\nWelcome to our  tiktok bot here you can download any tiktok video without watermark\nJust forward the tiktok link/url</i>', {
        parse_mode: 'HTML'
    })
})

bot.on('text', (ctx) => {
        let vido = ctx.message.text
        if (vido.includes('http')) {
            const options = {
                method: 'GET',
                url: 'https://tiktok-video-no-watermark2.p.rapidapi.com/',
                params: { url: vido, hd: '0' },
                headers: {
                    'X-RapidAPI-Host': 'tiktok-video-no-watermark2.p.rapidapi.com',
                    'X-RapidAPI-Key': 'e029be8030msh618c63937555372p1bb3ccjsn6262f03d6b6f'
                }
            };

            axios.request(options).then(function(response) {
                ctx.replyWithChatAction('upload_video')
                console.log(response.data)
                ctx.replyWithVideo(response.data.data.play, {
                    caption: '<i>If you like our bot kindly \nshare it with your friends\nlink: https://t.me/tiktokflix_bot\nJoin our Channel @socialflix</i>',
                    parse_mode: 'HTML'
                })
            })
        } else {
            ctx.replyWithMarkdown('_‼️ Please send tiktok https link/url_')
        }

    })
    // bot.launch()

exports.handler = (event, context, callback) => {
    const tmp = JSON.parse(event.body);
    bot.handleUpdate(tmp);
    return callback(null, {
        statusCode: 200,
        body: '',
    })
};